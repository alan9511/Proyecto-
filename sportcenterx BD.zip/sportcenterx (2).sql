-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-12-2016 a las 21:09:37
-- Versión del servidor: 10.1.10-MariaDB
-- Versión de PHP: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sportcenterx`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase`
--

CREATE TABLE `clase` (
  `Id_Clase` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Cupo` int(11) NOT NULL,
  `Horario` varchar(80) NOT NULL,
  `Mensualidad` decimal(7,2) NOT NULL,
  `Id_Entrenador` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clase`
--

INSERT INTO `clase` (`Id_Clase`, `Nombre`, `Cupo`, `Horario`, `Mensualidad`, `Id_Entrenador`) VALUES
(26, 'Zumba', 15, 'Horario: 5:00-6:00 pm', '500.00', NULL),
(30, 'Circuit', 12, 'Horario: 8:15-9:15 am', '450.00', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Id_Cliente` int(11) NOT NULL,
  `Nombre_Completo` varchar(80) NOT NULL,
  `Celular` int(11) NOT NULL,
  `Edad` int(11) NOT NULL,
  `Estatura` decimal(7,2) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Fecha_Mensualidad` date NOT NULL,
  `Disciplina` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Id_Cliente`, `Nombre_Completo`, `Celular`, `Edad`, `Estatura`, `Direccion`, `Fecha_Ingreso`, `Fecha_Mensualidad`, `Disciplina`) VALUES
(1, 'Alan Pedraza Mejia', 2347890, 21, '1.68', 'XALAPA', '2016-12-05', '2017-01-05', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenador`
--

CREATE TABLE `entrenador` (
  `Id_Entrenador` int(11) NOT NULL,
  `Usuario` varchar(80) NOT NULL,
  `Password` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `entrenador`
--

INSERT INTO `entrenador` (`Id_Entrenador`, `Usuario`, `Password`) VALUES
(2, 'meri', '12345'),
(3, 'samy', '1234'),
(4, 'alan', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscribe`
--

CREATE TABLE `inscribe` (
  `Id_Cliente` int(11) NOT NULL,
  `Id_Clase` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medida_corporal`
--

CREATE TABLE `medida_corporal` (
  `Id_Medida` int(11) NOT NULL,
  `Fecha_Prox_Medicion` date NOT NULL,
  `Peso` decimal(7,2) NOT NULL,
  `Medida_Pierna` decimal(7,2) NOT NULL,
  `Medida_Cintura` decimal(7,2) NOT NULL,
  `Observacion` varchar(200) NOT NULL,
  `Id_Cliente` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `Id_Pago` int(11) NOT NULL,
  `Fecha_Pago` date NOT NULL,
  `Pago_Total` decimal(7,2) NOT NULL,
  `Subtotal` decimal(7,2) DEFAULT NULL,
  `TipoVenta` varchar(80) DEFAULT NULL,
  `EstadoVenta` varchar(80) DEFAULT NULL,
  `Id_Clase` int(11) NOT NULL,
  `Id_Cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clase`
--
ALTER TABLE `clase`
  ADD PRIMARY KEY (`Id_Clase`),
  ADD KEY `fk_Clase_Entrenador_idx` (`Id_Entrenador`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`Id_Cliente`);

--
-- Indices de la tabla `entrenador`
--
ALTER TABLE `entrenador`
  ADD PRIMARY KEY (`Id_Entrenador`);

--
-- Indices de la tabla `inscribe`
--
ALTER TABLE `inscribe`
  ADD KEY `fk_Inscribe_Cliente_idx` (`Id_Cliente`),
  ADD KEY `fk_Inscribe_Clase_idx` (`Id_Clase`);

--
-- Indices de la tabla `medida_corporal`
--
ALTER TABLE `medida_corporal`
  ADD PRIMARY KEY (`Id_Medida`),
  ADD KEY `fk_MedidaCorporal_Cliente_idx` (`Id_Cliente`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`Id_Pago`),
  ADD KEY `fk_Pago_Clase_idx` (`Id_Clase`),
  ADD KEY `fk_Pago_Cliente_idx` (`Id_Cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clase`
--
ALTER TABLE `clase`
  MODIFY `Id_Clase` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `Id_Cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `entrenador`
--
ALTER TABLE `entrenador`
  MODIFY `Id_Entrenador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `medida_corporal`
--
ALTER TABLE `medida_corporal`
  MODIFY `Id_Medida` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pago`
--
ALTER TABLE `pago`
  MODIFY `Id_Pago` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clase`
--
ALTER TABLE `clase`
  ADD CONSTRAINT `fk_Clase_Entrenador` FOREIGN KEY (`Id_Entrenador`) REFERENCES `entrenador` (`Id_Entrenador`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `inscribe`
--
ALTER TABLE `inscribe`
  ADD CONSTRAINT `fk_Inscribe_Clase` FOREIGN KEY (`Id_Clase`) REFERENCES `clase` (`Id_Clase`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Inscribe_Cliente` FOREIGN KEY (`Id_Cliente`) REFERENCES `cliente` (`Id_Cliente`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `medida_corporal`
--
ALTER TABLE `medida_corporal`
  ADD CONSTRAINT `fk_MedidaCorporal_Cliente` FOREIGN KEY (`Id_Cliente`) REFERENCES `cliente` (`Id_Cliente`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `fk_Pago_Clase` FOREIGN KEY (`Id_Clase`) REFERENCES `clase` (`Id_Clase`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Pago_Cliente` FOREIGN KEY (`Id_Cliente`) REFERENCES `cliente` (`Id_Cliente`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
